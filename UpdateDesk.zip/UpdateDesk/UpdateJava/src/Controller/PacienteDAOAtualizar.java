package Controller;

import Model.PacienteAtualizar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAOAtualizar {
    
    private Connection con;
    private PreparedStatement cmd;
    
    public PacienteDAOAtualizar(){
        this.con = Conexao.Conectar();
    }
    
    public int atualizar(PacienteAtualizar p){
        try{
            String sql = "update paciente set nome=?, peso=?, altura=? where id=?;";
            
            cmd = con.prepareStatement(sql);
            cmd.setString(1, p.getNome());
            cmd.setFloat(2, p.getPeso());
            cmd.setFloat(3, p.getAltura());
            cmd.setInt(4, p.getId());
            
            if (cmd.executeUpdate() > 0){
                return p.getId();
            }
            else{
                return -1;
            }
            
        }
        catch (SQLException e){
            System.out.println("Erro: " + e.getMessage());
            return -1;
        }
        finally{
             Conexao.Desconectar(con);
        }
    }
    
    public List<PacienteAtualizar> listar(){
        try {
            String sql = "select * from paciente order by id";
            cmd = con.prepareStatement(sql);
            ResultSet rs = cmd.executeQuery();
            
            List<PacienteAtualizar> lista = new ArrayList<>();
            while(rs.next()){
                PacienteAtualizar p = new PacienteAtualizar();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setPeso(rs.getFloat("peso"));
                p.setAltura(rs.getFloat("altura"));
                
                lista.add(p); 
        } 
            return lista;
       }
        catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
                return null;
                }
        finally{
            Conexao.Desconectar(con);
        }
        }
}

